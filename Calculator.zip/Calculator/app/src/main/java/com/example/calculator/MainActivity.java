package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText data1;
    EditText data2;
    Button Btn_Add;
    Button Btn_Sub;
    Button Btn_Mul;
    Button Btn_div;
    Button Btn_Clear;
    EditText Btn_Answer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        data1= findViewById(R.id.data_1_input);
        data2= findViewById(R.id.data_2_input);


        Btn_Add=findViewById(R.id.btnAdd);
        Btn_Sub=findViewById(R.id.btnSub);
        Btn_Mul=findViewById(R.id.btnMul);
       Btn_div=findViewById(R.id.btnDiv);
        Btn_Clear=findViewById(R.id.btnClear);
      Btn_Answer=findViewById(R.id.Ans);

       Btn_Add.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {

               getValue();
               int sum = n1 + n2;
               Btn_Answer.setText("Sum = "+sum);
           }
       });
        Btn_Sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getValue();
                int sub = n1 - n2;
                Btn_Answer.setText("Sub = "+sub);
            }
        });
        Btn_Mul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getValue();
                int mul = n1 * n2;
                Btn_Answer.setText("Mul = "+mul);
            }
        });
        Btn_div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getValue();
                if(n1 != 0 && n2 != 0)
                {
                    int div = n1 / n2;
                    Btn_Answer.setText("Divide = "+div);
                }

            }
        });
        Btn_Clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                data1.setText("");
                data2.setText("");
            }
        });
    }

    public int n1, n2;

    public void getValue()
    {
        if(!data1.getText().toString().isEmpty() && !data2.getText().toString().isEmpty())
        {
            Log.e("TAG", "getValue: enter" );
            n1 = Integer.parseInt(data1.getText().toString());
            n2 = Integer.parseInt(data2.getText().toString());
        }else {
            n1 = 0;
            n2 = 0;
        }
    }

}