package com.example.ecomm;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class wishlist extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wishlist);
    }
}