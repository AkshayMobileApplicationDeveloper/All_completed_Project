package com.example.blackcoffer;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.skydoves.elasticviews.ElasticButton;

public class LoginActivity extends AppCompatActivity {
    ElasticButton btn_login;
    EditText txt_input_email;
    EditText txt_input_password;
    TextView Register_Acount;
    ElasticButton btn_closed;
    Intent intent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getWindow().setStatusBarColor(Color.parseColor("#006752"));


        btn_login = findViewById(R.id.btn_login);
        txt_input_email = findViewById(R.id.txt_input_email);
        txt_input_password = findViewById(R.id.txt_input_password);
        Register_Acount = findViewById(R.id.Register_Acount);

        txt_input_email.getText().toString();
        txt_input_password.getText().toString();



        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                
                if(conditionValid())
                {
                    Toast.makeText(LoginActivity.this, "login ", Toast.LENGTH_SHORT).show();
                    Log.d("TAG", "Email Id: " + txt_input_email.getText().toString());
                    Log.d("TAG", "Password: " + txt_input_password.getText().toString());

                    Dialog dialog= new Dialog(LoginActivity.this);
                    dialog.setContentView(R.layout.dialoge_successfully_login);
                    dialog.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.MATCH_PARENT);
                    dialog.getWindow().getAttributes().windowAnimations=R.style.Theme_Blackcoffer;
                    dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);



                    btn_closed=dialog.findViewById(R.id.btn_closed);
                    btn_closed.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            intent = new Intent(getApplicationContext(),LoginActivity.class);
                            startActivity(intent);
                            dialog.dismiss();

                        }
                    });
                    dialog.show();
                }
            }
        });

        Register_Acount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), RegisterActivity.class);
                startActivity(intent);
            }
        });


    }

    public boolean conditionValid() {
        if (txt_input_email.getText().toString().trim().isEmpty() && txt_input_password.getText().toString().trim().isEmpty()) {
            return false;
        }
        if (txt_input_email.getText().toString().isEmpty()) {
            Toast.makeText(LoginActivity.this, "Fill the Email", Toast.LENGTH_SHORT).show();
            return false;
        } else if (txt_input_password.getText().toString().isEmpty()) {
            Toast.makeText(LoginActivity.this, "Fill the password", Toast.LENGTH_SHORT).show();
            return false;
        } else if (txt_input_password.length() <= 7) {
            Toast.makeText(LoginActivity.this, "Min 8 digit", Toast.LENGTH_SHORT).show();
            return false;

        }
        return true;
    }

}