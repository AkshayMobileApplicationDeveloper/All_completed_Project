package com.example.blackcoffer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().setStatusBarColor(Color.parseColor("#006752"));


        new Timer().schedule(new TimerTask() {
            @Override
            public void run() {

                Intent intent=new Intent(getApplicationContext(), Introduction.class);
                finish();
                startActivity(intent);
                Log.e("TAG", "run: change Activity" );
            }
        },5000);
    }
}