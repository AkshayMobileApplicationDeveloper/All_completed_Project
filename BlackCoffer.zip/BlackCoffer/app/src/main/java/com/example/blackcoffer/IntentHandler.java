package com.example.blackcoffer;
import android.content.Context;
import android.content.Intent;

public class IntentHandler {

    public static void goToActivity(Context context, Class<?> cls) {
        Intent intent = new Intent(context, cls);
        context.startActivity(intent);
    }

    // You can create overloaded methods for passing data between activities
    public static void goToActivityWithExtra(Context context, Class<?> cls, String key, String value) {
        Intent intent = new Intent(context, cls);
        intent.putExtra(key, value);
        context.startActivity(intent);
    }

}

