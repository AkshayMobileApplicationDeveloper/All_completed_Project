package com.example.blackcoffer;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.skydoves.elasticviews.ElasticButton;

public class RegisterActivity extends AppCompatActivity {
    TextView Login_Acount;
    ElasticButton btn_Register;
    EditText txt_input_name;
    EditText txt_input_email;
    EditText txt_input_password;
    Dialog dialog;
    ElasticButton btn_closed;
    Intent intent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        getWindow().setStatusBarColor(Color.parseColor("#006752"));

        Login_Acount=findViewById(R.id.Login_Acount);
        btn_Register=findViewById(R.id.btn_Register);
        txt_input_name=findViewById(R.id.txt_input_name);
        txt_input_email=findViewById(R.id.txt_input_email);
        txt_input_password=findViewById(R.id.txt_input_password);



        txt_input_name.getText().toString();
        txt_input_email.getText().toString();
        txt_input_password.getText().toString();

        Login_Acount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
            }
        });
        btn_Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(conditionRegister())
                {
                    Log.e("TAG", "Name: " + txt_input_name.getText().toString());
                    Log.e("TAG", "Email: " + txt_input_email.getText().toString());
                    Log.e("TAG", "Password: " + txt_input_password.getText().toString());

                    dialog=new Dialog(RegisterActivity.this);
                    dialog.setContentView(R.layout.dialog_success_register);
                    dialog.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.MATCH_PARENT);
                    dialog.getWindow().getAttributes().windowAnimations=R.style.Theme_Blackcoffer;
                    dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

                    btn_closed=dialog.findViewById(R.id.btn_closed_01);

                    btn_closed.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            intent = new Intent(getApplicationContext(), RegisterActivity.class);
                            startActivity(intent);
                            dialog.dismiss();
                        }
                    });
                    dialog.show();


                }
            }
        });
    }
    public boolean conditionRegister()
    {
        if(txt_input_name.getText().toString().isEmpty()&& txt_input_email.getText().toString().isEmpty() && txt_input_password.getText().toString().isEmpty())
        {
            Toast.makeText(RegisterActivity.this, "fill the all field", Toast.LENGTH_SHORT).show();
            return false;
        }
        else if(txt_input_name.getText().toString().isEmpty())
        {
            Toast.makeText(RegisterActivity.this, "Full Name", Toast.LENGTH_SHORT).show();
            return false;
        }
        else if (txt_input_email.getText().toString().isEmpty()) {
            Toast.makeText(RegisterActivity.this, "Email ", Toast.LENGTH_SHORT).show();
            return false;
        } else if (txt_input_password.getText().toString().isEmpty())
        {
            Toast.makeText(RegisterActivity.this, "Password", Toast.LENGTH_SHORT).show();
            return false;
        }
        else if((txt_input_password.length())<=7)
        {
            Toast.makeText(RegisterActivity.this, "max Lenght 8 Digit", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
}