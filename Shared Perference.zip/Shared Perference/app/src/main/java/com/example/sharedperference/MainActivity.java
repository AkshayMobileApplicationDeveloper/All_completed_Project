package com.example.sharedperference;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Action Bar Hide
        getSupportActionBar().hide();

        new Handler().postDelayed(
                new Runnable() {
                    @Override
                    public void run() {
                        SharedPreferences preferences=getSharedPreferences("login",MODE_PRIVATE);
                        Boolean check =preferences.getBoolean("flag",false);

                        if(!check){
                            Intent intent=new Intent(getApplicationContext(),LoginActivity.class);
                            startActivity(intent);
                        }
                        else {
                            Intent intent=new Intent(getApplicationContext(),HomeActivity.class);
                            startActivity(intent);
                        }

                    }
                }, 4000);
            }
        }