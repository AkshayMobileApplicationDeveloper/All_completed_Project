package com.example.studentapp.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.studentapp.R;

import java.util.List;

public class StudentCardAdapter extends RecyclerView.Adapter<StudentCardAdapter.ViewHolder> {

    Context context;


    public StudentCardAdapter(Context context)
    {
           this.context = context;
    }

    @NonNull
    @Override
    public StudentCardAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.design_student_card,parent,false);
        return new StudentCardAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull StudentCardAdapter.ViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {

        return 5;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }
}
