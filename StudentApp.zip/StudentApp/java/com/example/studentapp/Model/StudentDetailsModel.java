package com.example.studentapp.Model;

public class StudentDetailsModel {
    private String StudentNameModel;
    private String StudentIDModel;
    private String StudentRegdNUmberModel;
    private String StudentSemesterModel;
    private String StudentMobileModel;
    private String StudentEmailModel;
    private String StudentCollegeModel;
    private String StudentAddressModel;

    public String getStudentNameModel() {
        return StudentNameModel;
    }

    public void setStudentNameModel(String studentNameModel) {
        this.StudentNameModel = studentNameModel;
    }

    public String getStudentIDModel() {
        return StudentIDModel;
    }

    public void setStudentIDModel(String studentIDModel) {
        this.StudentIDModel = studentIDModel;
    }

    public String getStudentRegdNUmberModel() {
        return StudentRegdNUmberModel;
    }

    public void setStudentRegdNUmberModel(String studentRegdNUmberModel) {
        this.StudentRegdNUmberModel = studentRegdNUmberModel;
    }

    public String getStudentSemesterModel() {
        return StudentSemesterModel;
    }

    public void setStudentSemesterModel(String studentSemesterModel) {
       this.StudentSemesterModel = studentSemesterModel;
    }

    public String getStudentMobileModel() {
        return StudentMobileModel;
    }

    public void setStudentMobileModel(String studentMobileModel) {
        this.StudentMobileModel = studentMobileModel;
    }

    public String getStudentEmailModel() {
        return StudentEmailModel;
    }

    public void setStudentEmailModel(String studentEmailModel) {
        this.StudentEmailModel = studentEmailModel;
    }

    public String getStudentCollegeModel() {
        return StudentCollegeModel;
    }

    public void setStudentCollegeModel(String studentCollegeModel) {
        this.StudentCollegeModel = studentCollegeModel;
    }

    public String getStudentAddressModel() {
        return StudentAddressModel;
    }

    public void setStudentAddressModel(String studentAddressModel) {
        this.StudentAddressModel = studentAddressModel;
    }

   ;

}
