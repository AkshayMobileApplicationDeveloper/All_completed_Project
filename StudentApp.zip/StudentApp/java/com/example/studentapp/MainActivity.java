package com.example.studentapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.studentapp.Adapter.StudentCardAdapter;
import com.example.studentapp.Model.StudentDetailsModel;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    RecyclerView idcardGenerate;
    StudentCardAdapter studentCardAdapter;
    EditText IDcardNumber,StudentName,RegdNumber,CurrentSeme,MobileNumber;
    EditText EmailAddress,CollegeName,AddressOfLocation;
   Button saved,IDCard;


  ArrayList<String>student=new ArrayList<>();
    StudentDetailsModel detailsModel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();



        saved=findViewById(R.id.btnsaved);
        IDCard=findViewById(R.id.btnprintid);
        idcardGenerate = findViewById(R.id.idcardGenerate);

        IDcardNumber=findViewById(R.id.IdNumber_INput);
        StudentName=findViewById(R.id.Student_Name_input);
        RegdNumber=findViewById(R.id.Regd_number_here_input);
        CurrentSeme=findViewById(R.id.Cureeent_Semester_inputer);
        MobileNumber=findViewById(R.id.MObile_here_input);
        EmailAddress=findViewById(R.id.email_here_input);
        CollegeName=findViewById(R.id.SchoolColegeDetails);
        AddressOfLocation=findViewById(R.id.locationaddress);



        saved.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e("TAG", "ID Card Number   :"+IDcardNumber.getText().toString());
                Log.e("TAG", "Student Name :"+StudentName.getText().toString() );
                Log.e("TAG", "Regd Number :"+RegdNumber.getText().toString() );
                Log.e("TAG", "Semester :"+CurrentSeme.getText().toString() );
                Log.e("TAG", "Mobile Number "+MobileNumber.getText().toString() );
                Log.e("TAG", "Email Address :"+EmailAddress.getText().toString());
                Log.e("TAG", ":College / Institute NAme"+CollegeName.getText().toString());
                Log.e("TAG", ":Address :  "+AddressOfLocation.getText().toString());

                Toast.makeText(MainActivity.this, "Save your details", Toast.LENGTH_SHORT).show();


            }
        });

       IDCard.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               GetAdmitCard();

               Toast.makeText(MainActivity.this, "Please Wait .................", Toast.LENGTH_SHORT).show();
           }
       });

    }



    public void GetAdmitCard()
    {
        studentCardAdapter = new StudentCardAdapter(getApplicationContext());

        idcardGenerate.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false));
        idcardGenerate.setAdapter(studentCardAdapter);

    }


}